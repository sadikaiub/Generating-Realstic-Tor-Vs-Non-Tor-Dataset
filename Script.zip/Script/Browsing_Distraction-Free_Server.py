import time
import random
import os
from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.chrome.options import Options as ChromeOptions
from selenium.webdriver.firefox.options import Options as FirefoxOptions
from urllib.parse import urlencode

# Configuration
SERVER_URL = "http://54.224.244.197"  # Base URL
BROWSING_SEQUENCE_FILE = "/media/sf_Dataset/Sequence/Web_Browsing_Sequence/Suchith_Web_Server_Sequence.txt"
RUN_MODE = "reuse"  # Set to "generate" to create the sequence, "reuse" to use an existing sequence
BROWSING_DURATION = 60 * 60  # Total browsing time (seconds)
TIME_LOWER_BOUND = 5  # Minimum time between requests (seconds)
TIME_UPPER_BOUND = 15  # Maximum time between requests (seconds)
SIZE_MIN = 500  # Minimum size value
SIZE_MAX = 5000  # Maximum size value
USE_TOR = True  # Set to True to route traffic through Tor
BROWSER_TYPE = "chrome"  # Options: "firefox" or "chrome"

# Configure Tor settings
#TOR_PROXY = "socks5://127.0.0.1:9150" if USE_TOR else None

# Setup the browser
def setup_browser():
    if BROWSER_TYPE.lower() == "chrome":
        options = ChromeOptions()
    elif BROWSER_TYPE.lower() == "firefox":
        options = FirefoxOptions()
    else:
        raise ValueError("Invalid browser type. Use 'firefox' or 'chrome'.")

    options.add_argument("--start-maximized")
    options.add_argument("--disable-blink-features=AutomationControlled")

    # if USE_TOR:
    #     print("Using Tor Proxy...")
    #     if BROWSER_TYPE.lower() == "firefox":
    #         options.set_preference("network.proxy.type", 1)
    #         options.set_preference("network.proxy.socks", "127.0.0.1")
    #         options.set_preference("network.proxy.socks_port", 9150)
    #         options.set_preference("network.proxy.socks_remote_dns", True)
    #     else:
    #         options.add_argument(f"--proxy-server={TOR_PROXY}")

    if BROWSER_TYPE.lower() == "chrome":
        driver = webdriver.Chrome(options=options)
    else:
        driver = webdriver.Firefox(options=options)

    return driver

# Generate browsing sequence
def generate_request_sequence(driver):
    print("Generating request sequence...")
    start_time = time.time()
    end_time = start_time + BROWSING_DURATION
    request_sequence = []

    while time.time() < end_time:
        try:
            # Generate a random size parameter
            size_value = random.randint(SIZE_MIN, SIZE_MAX)
            request_url = f"{SERVER_URL}/?size={size_value}"

            # Generate random request delay
            request_time = random.randint(TIME_LOWER_BOUND, TIME_UPPER_BOUND)

            # Save request to sequence file
            request_sequence.append(f"{request_url},{request_time}")

            # Open the URL in the browser
            print(f"Opening: {request_url} | Waiting: {request_time} seconds")
            driver.get(request_url)

            # Wait before the next request
            time.sleep(request_time)

        except Exception as e:
            print(f"Error making request: {e}. Retrying...")

    # Save the request sequence to a file
    with open(BROWSING_SEQUENCE_FILE, "w") as file:
        file.write("\n".join(request_sequence))
    print(f"Request sequence saved to {BROWSING_SEQUENCE_FILE}.")

# Reuse browsing sequence
def reuse_request_sequence(driver):
    print(f"Reusing request sequence from {BROWSING_SEQUENCE_FILE}...")
    if not os.path.exists(BROWSING_SEQUENCE_FILE):
        raise FileNotFoundError(f"{BROWSING_SEQUENCE_FILE} does not exist. Generate the sequence first.")

    with open(BROWSING_SEQUENCE_FILE, "r") as file:
        request_sequence = file.read().splitlines()

    for entry in request_sequence:
        try:
            # Split the line into URL and wait time
            parts = entry.rsplit(",", 1)
            if len(parts) != 2:
                print(f"Malformed entry skipped: {entry}")
                continue

            request_url, request_time = parts
            request_time = int(request_time.strip())

            print(f"Opening: {request_url.strip()} | Waiting: {request_time} seconds")
            driver.get(request_url.strip())

            time.sleep(request_time)

        except Exception as e:
            print(f"Error processing request '{entry}': {e}. Skipping...")

# # Test Tor connection
# def test_tor_connection(driver):
#     if not USE_TOR:
#         return
#     try:
#         print("Testing Tor connection...")
#         driver.get("https://check.torproject.org/")
#         time.sleep(5)
#         if "Congratulations. This browser is configured to use Tor." in driver.page_source:
#             print("Successfully connected to Tor!")
#         else:
#             print("Tor is NOT working. Please check your Tor configuration.")
#     except Exception as e:
#         print(f"Error testing Tor connection: {e}")

# Main function
def main():
    driver = setup_browser()
    try:
        # test_tor_connection(driver)
        if RUN_MODE == "generate":
            generate_request_sequence(driver)
        elif RUN_MODE == "reuse":
            reuse_request_sequence(driver)
        else:
            raise ValueError("Invalid RUN_MODE. Use 'generate' or 'reuse'.")
    finally:
        driver.quit()

if __name__ == "__main__":
    main()
