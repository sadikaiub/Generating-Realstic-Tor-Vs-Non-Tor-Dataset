import time
import random
import os
import subprocess
import signal
from selenium import webdriver
from selenium.webdriver.chrome.options import Options
from selenium.webdriver.common.by import By

# =======================
# Configuration
# =======================
URL_SEQUENCE_FILE = "/media/sf_Thesis_Dataset/Dataset/Sequence/Web_Browsing_Sequence/Wekipedia_url_sequence.txt"
PCAP_OUTPUT_FILE = "/media/sf_Thesis_Dataset/Dataset/Pcap_File/Web_Browsing_Pcap/Non_Wekipedia_Traffic_Capture.pcapng"
INTERFACE = "enp0s3"  # Change to your actual interface
RUN_MODE = "reuse"  # "generate" or "reuse"
BROWSING_DURATION = 60 * 60  # 1 hour
TIME_LOWER_BOUND = 5
TIME_UPPER_BOUND = 15
WIKIPEDIA_MAIN_PAGE = "https://en.wikipedia.org/wiki/Main_Page"

# =======================
# TShark Start/Stop
# =======================
def start_tshark_capture():
    print("📡 Starting tshark capture...")
    cmd = ["tshark", "-i", INTERFACE, "-w", PCAP_OUTPUT_FILE, "-q"]
    return subprocess.Popen(cmd, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)

def stop_tshark(process):
    print("Stopping tshark capture...")
    process.send_signal(signal.SIGINT)
    process.wait()
    print(f" Traffic capture saved to: {PCAP_OUTPUT_FILE}")

# =======================
# Setup Chrome Browser
# =======================
def setup_browser():
    options = Options()
    options.add_argument("--start-maximized")
    options.add_argument("--disable-blink-features=AutomationControlled")
    # options.add_argument("--proxy-server=socks5://127.0.0.1:9050")  # Uncomment if testing with Tor proxy manually
    driver = webdriver.Chrome(options=options)
    return driver

# =======================
# Test Tor Connectivity
# =======================
def test_tor_connection(driver):
    print("🔍 Testing Tor connectivity...")
    try:
        driver.get("https://check.torproject.org/")
        time.sleep(5)
        page_source = driver.page_source
        if "Congratulations. This browser is configured to use Tor." in page_source:
            print("Tor is ACTIVE. Traffic is going through the Tor network.")
        else:
            print("Tor is NOT active. Traffic is going through the regular internet.")
    except Exception as e:
        print(f" Failed to test Tor connectivity: {e}")

# =======================
# Generate URL Sequence
# =======================
def get_url_sequence(driver):
    print(" Generating URL sequence...")
    driver.get(WIKIPEDIA_MAIN_PAGE)
    url_sequence = []
    start_time = time.time()
    end_time = start_time + BROWSING_DURATION

    while time.time() < end_time:
        try:
            links = driver.find_elements(By.CSS_SELECTOR, "#bodyContent a[href^='/wiki/']:not([href*=':'])")
            valid_links = [link for link in links if link.is_displayed() and "/wiki/Main_Page" not in link.get_attribute("href")]

            if valid_links:
                random_link = random.choice(valid_links)
                article_url = random_link.get_attribute("href")
                time_on_page = random.randint(TIME_LOWER_BOUND, TIME_UPPER_BOUND)

                url_sequence.append(f"{article_url},{time_on_page}")
                driver.execute_script("arguments[0].scrollIntoView(true);", random_link)
                time.sleep(1)
                random_link.click()

                print(f" Visited: {article_url} | ⏱Time spent: {time_on_page}s")
                time.sleep(time_on_page)
            else:
                print("No valid links found. Reloading main page.")
                driver.get(WIKIPEDIA_MAIN_PAGE)

        except Exception as e:
            print(f" Error: {e}. Returning to main page.")
            driver.get(WIKIPEDIA_MAIN_PAGE)

    with open(URL_SEQUENCE_FILE, "w") as file:
        file.write("\n".join(url_sequence))
    print(f" URL sequence saved to {URL_SEQUENCE_FILE}")

# =======================
# Reuse URL Sequence
# =======================
def reuse_url_sequence(driver):
    print(f" Reusing URL sequence from: {URL_SEQUENCE_FILE}")
    if not os.path.exists(URL_SEQUENCE_FILE):
        raise FileNotFoundError(f"{URL_SEQUENCE_FILE} does not exist.")

    with open(URL_SEQUENCE_FILE, "r") as file:
        url_sequence = file.read().splitlines()

    for entry in url_sequence:
        try:
            parts = entry.rsplit(",", 1)
            if len(parts) != 2:
                print(f" Malformed entry skipped: {entry}")
                continue

            url, time_on_page = parts
            time_on_page = int(time_on_page.strip())

            print(f" Visiting: {url.strip()} |  Time: {time_on_page}s")
            driver.get(url.strip())
            time.sleep(time_on_page)
        except Exception as e:
            print(f" Error on entry '{entry}': {e}")

# =======================
# Main Function
# =======================
def main():
    tshark_proc = start_tshark_capture()
    time.sleep(5)  # Let tshark initialize

    driver = setup_browser()
    try:
        test_tor_connection(driver)

        if RUN_MODE == "generate":
            get_url_sequence(driver)
        elif RUN_MODE == "reuse":
            reuse_url_sequence(driver)
        else:
            raise ValueError("RUN_MODE must be 'generate' or 'reuse'")
    finally:
        driver.quit()
        stop_tshark(tshark_proc)

# =======================
# Entry Point
# =======================
if __name__ == "__main__":
    main()
