import time
import random
import os
import requests
import subprocess
import signal

# === Configuration ===
RUN_MODE = "generate"  # Options: "generate" or "reuse"
TRANSFER_DURATION = 60 * 60  # Total transfer time in seconds (e.g., 1 hour)
SEQUENCE_FILE = "/media/sf_Dataset/Pcap_File/New_File_10_50/50MB_Download_Sequence.txt"
DOWNLOAD_FOLDER = "/media/sf_Dataset/Pcap_File/New_File_10_50/Files"
PCAP_OUTPUT_PATH = "/media/sf_Dataset/Pcap_File/New_File_10_50/Non_Tor_50MB_File_Download.pcapng"
INTERFACE_NAME = "enp0s3"  # Replace with your actual network interface (e.g., enp0s8)

# === Gap Between Downloads (in seconds) ===
GAP_LOWER_BOUND = 5
GAP_UPPER_BOUND = 15

# === File Size Selection ===
# Set to 10, 50, 100 for fixed size — or None for random selection
TARGET_SIZE_MB = 50  # Options: 10, 50, 100, or None

# === Server File Paths ===
SERVER_URL = "http://54.224.244.197"
STATIC_FILES = {
    10: "random_10MB.dat",
    50: "random_50MB.dat",
    100: "random_100MB.dat",
}


def download_file(url, dest_path):
    with requests.get(url, stream=True, timeout=(10, 60)) as r:
        r.raise_for_status()
        with open(dest_path, "wb") as f:
            for chunk in r.iter_content(chunk_size=8192):
                f.write(chunk)


def start_tshark_capture():
    cmd = ["sudo", "tshark", "-i", INTERFACE_NAME, "-w", PCAP_OUTPUT_PATH]
    return subprocess.Popen(cmd)


def stop_tshark_capture(proc):
    proc.terminate()
    proc.wait()


def generate_transfer_sequence():
    start_time = time.time()
    end_time = start_time + TRANSFER_DURATION
    sequence = []

    os.makedirs(DOWNLOAD_FOLDER, exist_ok=True)

    while True:
        now = time.time()
        remaining_time = end_time - now

        # Estimate the maximum time needed for a download + gap
        estimated_download_time = 60  # Conservative estimate
        estimated_gap = GAP_UPPER_BOUND
        estimated_total_time = estimated_download_time + estimated_gap

        if remaining_time < estimated_total_time:
            print(f"Time remaining ({remaining_time:.1f}s) too short — stopping transfers.")
            break

        # Select file size (fixed or random)
        if TARGET_SIZE_MB in STATIC_FILES:
            size_mb = TARGET_SIZE_MB
        else:
            size_mb = random.choice(list(STATIC_FILES.keys()))

        filename = STATIC_FILES[size_mb]
        url = f"{SERVER_URL}/{filename}"
        timestamp = int(now)
        local_name = f"{filename.split('.')[0]}_{timestamp}.dat"
        full_path = os.path.join(DOWNLOAD_FOLDER, local_name)

        print(f"Downloading: {local_name}")
        try:
            download_file(url, full_path)
            wait_time = random.randint(GAP_LOWER_BOUND, GAP_UPPER_BOUND)
            sequence.append(f"{local_name},{wait_time}")
            print(f"Waiting {wait_time} seconds before next download...\n")
            time.sleep(wait_time)
        except Exception as e:
            print(f"Failed to download {filename}: {e}")

    with open(SEQUENCE_FILE, "w") as f:
        f.write("\n".join(sequence))
    print(f"Saved sequence to {SEQUENCE_FILE}")


def reuse_transfer_sequence():
    if not os.path.exists(SEQUENCE_FILE):
        print(f"{SEQUENCE_FILE} not found!")
        return

    with open(SEQUENCE_FILE, "r") as f:
        sequence = f.read().splitlines()

    os.makedirs(DOWNLOAD_FOLDER, exist_ok=True)

    for entry in sequence:
        try:
            filename, wait_time = entry.strip().split(",")
            size = int(filename.split("_")[1].replace("MB", ""))
            url = f"{SERVER_URL}/{STATIC_FILES[size]}"
            full_path = os.path.join(DOWNLOAD_FOLDER, filename)

            print(f"Re-downloading: {filename}")
            download_file(url, full_path)
            print(f"Waiting {wait_time} seconds before next download...\n")
            time.sleep(int(wait_time))
        except Exception as e:
            print(f"Error on entry '{entry}': {e}")


def main():
    # === Set a hard timeout for the script ===
    def timeout_handler(signum, frame):
        print("\n⏰ Transfer duration limit reached — forcefully stopping script.")
        raise TimeoutError("Script exceeded maximum allowed duration.")

    signal.signal(signal.SIGALRM, timeout_handler)
    signal.alarm(TRANSFER_DURATION)  # Set hard stop at 1 hour

    start = time.time()
    print(f"Starting tshark capture: {PCAP_OUTPUT_PATH}")
    tshark_proc = start_tshark_capture()

    try:
        if RUN_MODE == "generate":
            generate_transfer_sequence()
        elif RUN_MODE == "reuse":
            reuse_transfer_sequence()
        else:
            print(f"Unknown RUN_MODE: {RUN_MODE}")
    except TimeoutError:
        print("⛔ Script terminated due to time limit.")
    except KeyboardInterrupt:
        print("Interrupted by user.")
    finally:
        print("Stopping tshark capture...")
        stop_tshark_capture(tshark_proc)

        end = time.time()
        elapsed = end - start
        print(f"\n✅ Script runtime: {elapsed:.2f} seconds ({elapsed / 60:.2f} minutes)")
        print("📁 Capture saved to:", PCAP_OUTPUT_PATH)


if __name__ == "__main__":
    main()
