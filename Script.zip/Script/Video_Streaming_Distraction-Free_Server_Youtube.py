import time
import random
import os
import subprocess
from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.chrome.options import Options as ChromeOptions
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC

# === Configuration ===
MODE = "reuse"  # "generate" or "reuse"
VIDEO_SOURCE = "youtube"  # "youtube" or "Distraction-Free_Server"

# === Common Settings ===
TIME_LOWER_BOUND = 60      # Min playback time per video
TIME_UPPER_BOUND = 300     # Max playback time per video
STREAM_DURATION = 60 * 60  # Total duration in seconds
DESIRED_QUALITY = "240"   # "240", "480", "720", "1080", or "any"
VIDEO_SEQUENCE_FILE = "/media/sf_Dataset/Sequence/Video_Streaming_Sequence/Clean_Server/240P_Clear_Server_Sequence.txt"
INTERFACE_NAME = "enp0s3"  # Replace with your actual network interface
PCAP_OUTPUT_PATH = "/media/sf_Dataset/Pcap_File/Video_Streaming_Pcap/Clean_Server/Non_Tor_240P_Video_Stream.pcapng"

# === YouTube Settings ===
PLAYLIST_URL = "https://www.youtube.com/playlist?list=PLuR0wUGZPbMuP5-wXE2sU6lKBccMWDn3s"
TITLE_KEYWORDS = [DESIRED_QUALITY]

# === Custom Server Settings ===
SERVER_URL = "http://54.224.244.197/video.php"

def setup_browser():
    options = ChromeOptions()
    options.add_argument("--start-maximized")
    options.add_argument("--disable-blink-features=AutomationControlled")
    options.add_argument("--autoplay-policy=no-user-gesture-required")
    options.add_argument("--mute-audio")
    options.add_argument("user-agent=Mozilla/5.0")
    prefs = {
        "profile.default_content_setting_values.media_stream_camera": 1,
        "profile.default_content_setting_values.media_stream_mic": 1,
        "profile.default_content_setting_values.media_stream": 1,
    }
    options.add_experimental_option("prefs", prefs)
    return webdriver.Chrome(options=options)

def extract_youtube_links(driver):
    print("Extracting video links from YouTube playlist...")
    driver.get(PLAYLIST_URL)
    WebDriverWait(driver, 15).until(EC.presence_of_all_elements_located((By.ID, "video-title")))
    elements = driver.find_elements(By.ID, "video-title")
    links = []

    for element in elements:
        title = element.get_attribute("title")
        href = element.get_attribute("href")
        if href and "watch?v=" in href and title:
            if DESIRED_QUALITY == "any" or any(keyword.lower() in title.lower() for keyword in TITLE_KEYWORDS):
                links.append(href)
                print(f"Matched title: {title}")
    print(f"Found {len(links)} matching video links.")
    return links

def extract_custom_links(driver):
    driver.get(SERVER_URL)
    WebDriverWait(driver, 10).until(EC.presence_of_all_elements_located((By.CSS_SELECTOR, "a[href$='.mp4'], a[href$='.webm']")))
    elements = driver.find_elements(By.CSS_SELECTOR, "a[href$='.mp4'], a[href$='.webm']")
    all_links = [e.get_attribute("href") for e in elements if e.is_displayed()]
    return all_links if DESIRED_QUALITY == "any" else [url for url in all_links if DESIRED_QUALITY in url]

def play_video(driver, source):
    try:
        WebDriverWait(driver, 10).until(EC.presence_of_element_located((By.TAG_NAME, "video")))
        driver.execute_script("""
            var video = document.querySelector('video');
            if (video) {
                video.muted = true;
                video.play();
            }
        """)
        if source == "youtube" and DESIRED_QUALITY != "any":
            try:
                settings = WebDriverWait(driver, 5).until(EC.element_to_be_clickable((By.CLASS_NAME, "ytp-settings-button")))
                settings.click()
                time.sleep(0.5)
                quality_menu = driver.find_elements(By.XPATH, '//div[contains(text(), "Quality")]')
                if quality_menu:
                    quality_menu[0].click()
                    time.sleep(0.5)
                    quality_option = driver.find_elements(By.XPATH, f'//span[contains(text(), "{DESIRED_QUALITY}")]')
                    if quality_option:
                        quality_option[0].click()
                        print(f"Quality set to {DESIRED_QUALITY}")
            except:
                print("Failed to set quality (may not be available).")
        print("Video playback started.")
        return True
    except Exception as e:
        print(f"Video playback error: {e}")
        return False

def generate_video_sequence(driver):
    links = extract_youtube_links(driver) if VIDEO_SOURCE == "youtube" else extract_custom_links(driver)
    if not links:
        print("No video links found. Exiting.")
        return
    sequence = []
    start_time = time.time()
    end_time = start_time + STREAM_DURATION

    while time.time() < end_time:
        video_url = random.choice(links)
        playback_time = random.randint(TIME_LOWER_BOUND, TIME_UPPER_BOUND)
        sequence.append(f"{video_url},{playback_time}")
        print(f"Streaming: {video_url} | Duration: {playback_time} seconds")
        driver.get(video_url)
        time.sleep(5)
        if play_video(driver, VIDEO_SOURCE):
            time.sleep(playback_time)
        else:
            print("Playback failed. Skipping.")
        time.sleep(random.uniform(1, 3))

    with open(VIDEO_SEQUENCE_FILE, "w") as f:
        f.write("\n".join(sequence))
    print(f"Saved sequence to {VIDEO_SEQUENCE_FILE}")

def reuse_video_sequence(driver):
    if not os.path.exists(VIDEO_SEQUENCE_FILE):
        raise FileNotFoundError(f"{VIDEO_SEQUENCE_FILE} not found!")
    with open(VIDEO_SEQUENCE_FILE, "r") as f:
        sequence = f.read().splitlines()
    for entry in sequence:
        try:
            url, duration = entry.strip().split(",")
            print(f"Streaming: {url} | Duration: {duration}")
            driver.get(url)
            time.sleep(5)
            if play_video(driver, VIDEO_SOURCE):
                time.sleep(int(duration))
            else:
                print("Playback failed. Skipping.")
        except Exception as e:
            print(f"Error on entry '{entry}': {e}")

def test_tor_connection(driver):
    try:
        print("Testing if traffic is routed through Tor...")
        driver.get("https://check.torproject.org/")
        time.sleep(5)
        if "Congratulations. This browser is configured to use Tor." in driver.page_source:
            print("✅ Connected to Tor!")
        else:
            print("❌ Not using Tor. Please check configuration.")
    except Exception as e:
        print(f"Tor check error: {e}")

def start_tshark_capture(interface, output_path):
    print(f"🟢 Starting tshark on {interface}, saving to {output_path}")
    return subprocess.Popen(["tshark", "-i", interface, "-w", output_path], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)

def stop_tshark_capture(proc):
    print("🛑 Stopping tshark...")
    proc.terminate()
    proc.wait()
    print("✅ tshark capture saved.")

def main():
    driver = setup_browser()
    tshark_proc = start_tshark_capture(INTERFACE_NAME, PCAP_OUTPUT_PATH)

    try:
        test_tor_connection(driver)
        if MODE == "generate":
            generate_video_sequence(driver)
        elif MODE == "reuse":
            reuse_video_sequence(driver)
        else:
            print(f"Unknown MODE: {MODE}")
    except KeyboardInterrupt:
        print("Interrupted by user.")
    finally:
        stop_tshark_capture(tshark_proc)
        driver.quit()

if __name__ == "__main__":
    main()
